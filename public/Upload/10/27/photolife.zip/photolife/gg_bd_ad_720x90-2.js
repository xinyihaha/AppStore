//document.writeln("<div style=\"width:728px;margin:10px auto;\">")
//document.writeln('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
//document.writeln('<!-- html5tricks-demo-2 -->');
//document.writeln('<ins class="adsbygoogle"');
//document.writeln('     style="display:inline-block;width:728px;height:90px"');
//document.writeln('     data-ad-client="ca-pub-4188263447419139"');
//document.writeln('     data-ad-slot="7681851201"></ins>');
//document.writeln('<script>');
//document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
//document.writeln('</script>');
//document.writeln("</div>");


//document.writeln("<div style=\"width:728px;margin:10px auto;\">")
//document.writeln('<script type="text/javascript">');
//document.writeln('var cpro_id="u1990325";');
//document.writeln('(window["cproStyleApi"] = window["cproStyleApi"] || {})[cpro_id]={at:"3",rsi0:"728",rsi1:"250",pat:"6",tn:"baiduCustNativeAD",rss1:"#FFFFFF",conBW:"1",adp:"1",ptt:"1",ptc:"%E7%8C%9C%E4%BD%A0%E6%84%9F%E5%85%B4%E8%B6%A3",ptFS:"14",ptFC:"#000000",ptBC:"#F2F2F2",titFF:"%E5%BE%AE%E8%BD%AF%E9%9B%85%E9%BB%91",titFS:"14",rss2:"#000000",titSU:"0",ptbg:"70",piw:"0",pih:"0",ptp:"0"}');
//document.writeln('</script>');
//document.writeln('<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>');
//document.writeln("</div>");